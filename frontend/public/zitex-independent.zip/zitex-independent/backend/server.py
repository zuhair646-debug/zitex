from fastapi import FastAPI, APIRouter, HTTPException, Depends, UploadFile, File, Form
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
from pathlib import Path
from pydantic import BaseModel, Field, ConfigDict, EmailStr
from typing import List, Optional, Literal
import uuid
from datetime import datetime, timezone, timedelta
import bcrypt
import jwt
from openai import OpenAI
import google.generativeai as genai
from elevenlabs import ElevenLabs
from elevenlabs.types import VoiceSettings
import base64
import httpx
from PIL import Image, ImageDraw, ImageFont
import io

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

app = FastAPI(title="Zitex API - Independent", description="AI-Powered Creative Platform - Independent Version")
api_router = APIRouter(prefix="/api")

security = HTTPBearer()
JWT_SECRET = os.environ.get('JWT_SECRET', 'your-secret-key')
OPENAI_API_KEY = os.environ.get('OPENAI_API_KEY')
GEMINI_API_KEY = os.environ.get('GEMINI_API_KEY')
OWNER_WHATSAPP = os.environ.get('OWNER_WHATSAPP', '')
ELEVENLABS_API_KEY = os.environ.get('ELEVENLABS_API_KEY')

# Initialize OpenAI client
openai_client = OpenAI(api_key=OPENAI_API_KEY) if OPENAI_API_KEY else None

# Initialize Gemini
if GEMINI_API_KEY:
    genai.configure(api_key=GEMINI_API_KEY)

# Initialize ElevenLabs client
eleven_client = ElevenLabs(api_key=ELEVENLABS_API_KEY) if ELEVENLABS_API_KEY else None

# ============== MODELS ==============

# Role levels: owner (100) > super_admin (80) > admin (50) > client (10)
ROLE_LEVELS = {
    "owner": 100,
    "super_admin": 80,
    "admin": 50,
    "client": 10
}

class UserRegister(BaseModel):
    email: EmailStr
    password: str
    name: str
    country: str = "SA"

class UserLogin(BaseModel):
    email: EmailStr
    password: str

class User(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    email: str
    name: str
    role: str = "client"
    country: str = "SA"
    credits: float = 0
    free_images: int = 3
    free_videos: int = 3
    free_website_trial: bool = True
    subscription_type: Optional[str] = None
    subscription_expires: Optional[str] = None
    is_owner: bool = False
    is_active: bool = True
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class ActivityLog(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    user_id: str
    user_name: str
    user_email: str
    action: str  # image_generated, video_generated, website_requested, payment_created, download, etc.
    action_type: str  # create, download, edit, delete
    details: Optional[str] = None
    metadata: Optional[dict] = None
    ip_address: Optional[str] = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class VoiceInfo(BaseModel):
    voice_id: str
    name: str
    category: str
    gender: str
    language: str
    accent: str

class TTSRequest(BaseModel):
    text: str
    voice_id: str
    stability: float = 0.5
    similarity_boost: float = 0.75

class ImageEditRequest(BaseModel):
    image_base64: str
    text: Optional[str] = None
    text_position: Optional[str] = "bottom"  # top, center, bottom
    text_color: Optional[str] = "#FFFFFF"
    font_size: Optional[int] = 40

class ImageGeneration(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    user_id: str
    prompt: str
    image_url: Optional[str] = None
    edited_image_url: Optional[str] = None
    status: str = "pending"
    is_free: bool = False
    is_edit: bool = False
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class VideoGeneration(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    user_id: str
    prompt: str
    video_url: Optional[str] = None
    audio_url: Optional[str] = None
    voice_id: Optional[str] = None
    status: str = "pending"
    is_free: bool = False
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class WebsiteRequestCreate(BaseModel):
    title: str
    description: str
    requirements: str
    business_type: Optional[str] = None
    target_audience: Optional[str] = None
    preferred_colors: Optional[str] = None
    is_trial: bool = False

class WebsiteRequest(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    user_id: str
    title: str
    description: str
    requirements: str
    business_type: Optional[str] = None
    target_audience: Optional[str] = None
    preferred_colors: Optional[str] = None
    ai_suggestions: Optional[str] = None
    status: str = "pending"
    credits_used: float = 0
    is_trial: bool = False
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class PaymentCreate(BaseModel):
    payment_type: str
    amount: float
    proof_base64: Optional[str] = None

class Payment(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    user_id: str
    user_name: Optional[str] = None
    user_email: Optional[str] = None
    payment_type: str
    amount: float
    currency: str
    proof_image_url: Optional[str] = None
    status: str = "pending"
    admin_notes: Optional[str] = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class Website(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    request_id: str
    user_id: str
    url: str
    preview_image: Optional[str] = None
    content: Optional[str] = None
    status: str = "draft"
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class SiteSettings(BaseModel):
    bank_name: Optional[str] = None
    bank_iban: Optional[str] = None
    bank_account_name: Optional[str] = None
    paypal_email: Optional[str] = None
    owner_whatsapp: Optional[str] = None

class AdminStats(BaseModel):
    total_users: int
    total_requests: int
    pending_requests: int
    completed_requests: int
    pending_payments: int
    approved_payments: int
    total_websites: int
    total_images_generated: int
    total_videos_generated: int
    total_activities: int

# ============== HELPERS ==============

def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')

def verify_password(password: str, hashed: str) -> bool:
    return bcrypt.checkpw(password.encode('utf-8'), hashed.encode('utf-8'))

def create_token(user_id: str, role: str) -> str:
    payload = {
        'user_id': user_id,
        'role': role,
        'exp': datetime.now(timezone.utc) + timedelta(days=7)
    }
    return jwt.encode(payload, JWT_SECRET, algorithm='HS256')

async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)):
    try:
        payload = jwt.decode(credentials.credentials, JWT_SECRET, algorithms=['HS256'])
        user_id = payload.get('user_id')
        role = payload.get('role')
        if not user_id:
            raise HTTPException(status_code=401, detail="Invalid token")
        return {'user_id': user_id, 'role': role}
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expired")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token")

async def require_role(min_role: str, current_user: dict):
    """Check if user has minimum required role level"""
    user_doc = await db.users.find_one({"id": current_user['user_id']}, {"_id": 0})
    if not user_doc:
        raise HTTPException(status_code=404, detail="User not found")
    
    user_role = user_doc.get('role', 'client')
    user_level = ROLE_LEVELS.get(user_role, 0)
    required_level = ROLE_LEVELS.get(min_role, 0)
    
    if user_level < required_level:
        raise HTTPException(status_code=403, detail=f"Requires {min_role} role or higher")
    
    return user_doc

async def require_admin(current_user: dict = Depends(get_current_user)):
    return await require_role("admin", current_user)

async def require_super_admin(current_user: dict = Depends(get_current_user)):
    return await require_role("super_admin", current_user)

async def require_owner(current_user: dict = Depends(get_current_user)):
    return await require_role("owner", current_user)

async def check_user_subscription(user_id: str, sub_type: str) -> bool:
    user_doc = await db.users.find_one({"id": user_id}, {"_id": 0})
    if not user_doc:
        return False
    if user_doc.get('is_owner'):
        return True
    if user_doc.get('subscription_type') == sub_type:
        expires = user_doc.get('subscription_expires')
        if expires and datetime.fromisoformat(expires) > datetime.now(timezone.utc):
            return True
    return False

async def log_activity(user_id: str, action: str, action_type: str, details: str = None, metadata: dict = None):
    """Log user activity"""
    user_doc = await db.users.find_one({"id": user_id}, {"_id": 0})
    if not user_doc:
        return
    
    log = ActivityLog(
        user_id=user_id,
        user_name=user_doc.get('name', 'Unknown'),
        user_email=user_doc.get('email', ''),
        action=action,
        action_type=action_type,
        details=details,
        metadata=metadata
    )
    
    doc = log.model_dump()
    doc['created_at'] = doc['created_at'].isoformat()
    await db.activity_logs.insert_one(doc)

async def send_whatsapp_notification(message: str):
    """Send WhatsApp notification to owner"""
    try:
        phone = OWNER_WHATSAPP
        settings = await db.settings.find_one({"type": "payment"}, {"_id": 0})
        if settings and settings.get('owner_whatsapp'):
            phone = settings.get('owner_whatsapp')
        
        import urllib.parse
        encoded_msg = urllib.parse.quote(message)
        url = f"https://api.callmebot.com/whatsapp.php?phone={phone}&text={encoded_msg}&apikey=123456"
        
        async with httpx.AsyncClient() as client:
            try:
                await client.get(url, timeout=10)
            except:
                pass
        
        logging.info(f"WhatsApp notification sent to {phone}")
        return True
    except Exception as e:
        logging.error(f"WhatsApp notification failed: {str(e)}")
        return False

# ============== AUTH ROUTES ==============

@api_router.post("/auth/register")
async def register(user_data: UserRegister):
    existing = await db.users.find_one({"email": user_data.email}, {"_id": 0})
    if existing:
        raise HTTPException(status_code=400, detail="Email already registered")
    
    user = User(
        email=user_data.email,
        name=user_data.name,
        role="client",
        country=user_data.country,
        credits=0,
        free_images=3,
        free_videos=3,
        free_website_trial=True
    )
    
    doc = user.model_dump()
    doc['password'] = hash_password(user_data.password)
    doc['created_at'] = doc['created_at'].isoformat()
    
    await db.users.insert_one(doc)
    await log_activity(user.id, "user_registered", "create", f"New user registered: {user.email}")
    
    token = create_token(user.id, user.role)
    return {"token": token, "user": user}

@api_router.post("/auth/login")
async def login(credentials: UserLogin):
    user_doc = await db.users.find_one({"email": credentials.email}, {"_id": 0})
    if not user_doc or not verify_password(credentials.password, user_doc['password']):
        raise HTTPException(status_code=401, detail="Invalid credentials")
    
    if not user_doc.get('is_active', True):
        raise HTTPException(status_code=403, detail="Account is deactivated")
    
    for field in ['free_images', 'free_videos', 'free_website_trial']:
        if field not in user_doc:
            user_doc[field] = 0 if field != 'free_website_trial' else False
    
    user = User(**{k: v for k, v in user_doc.items() if k != 'password'})
    await log_activity(user.id, "user_login", "create", f"User logged in")
    
    token = create_token(user.id, user.role)
    return {"token": token, "user": user}

@api_router.get("/auth/me")
async def get_me(current_user: dict = Depends(get_current_user)):
    user_doc = await db.users.find_one({"id": current_user['user_id']}, {"_id": 0, "password": 0})
    if not user_doc:
        raise HTTPException(status_code=404, detail="User not found")
    
    for field in ['free_images', 'free_videos', 'free_website_trial']:
        if field not in user_doc:
            user_doc[field] = 0 if field != 'free_website_trial' else False
    
    return user_doc

# ============== VOICES ==============

# Pre-defined voices for Arabic and English
AVAILABLE_VOICES = [
    {"voice_id": "21m00Tcm4TlvDq8ikWAM", "name": "Rachel", "category": "premade", "gender": "female", "language": "en", "accent": "American"},
    {"voice_id": "AZnzlk1XvdvUeBnXmlld", "name": "Domi", "category": "premade", "gender": "female", "language": "en", "accent": "American"},
    {"voice_id": "EXAVITQu4vr4xnSDxMaL", "name": "Bella", "category": "premade", "gender": "female", "language": "en", "accent": "American"},
    {"voice_id": "ErXwobaYiN019PkySvjV", "name": "Antoni", "category": "premade", "gender": "male", "language": "en", "accent": "American"},
    {"voice_id": "VR6AewLTigWG4xSOukaG", "name": "Arnold", "category": "premade", "gender": "male", "language": "en", "accent": "American"},
    {"voice_id": "pNInz6obpgDQGcFmaJgB", "name": "Adam", "category": "premade", "gender": "male", "language": "en", "accent": "American"},
    {"voice_id": "yoZ06aMxZJJ28mfd3POQ", "name": "Sam", "category": "premade", "gender": "male", "language": "en", "accent": "American"},
    {"voice_id": "onwK4e9ZLuTAKqWW03F9", "name": "Daniel", "category": "premade", "gender": "male", "language": "en", "accent": "British"},
    {"voice_id": "XB0fDUnXU5powFXDhCwa", "name": "Charlotte", "category": "premade", "gender": "female", "language": "en", "accent": "British"},
]

@api_router.get("/voices")
async def get_voices(current_user: dict = Depends(get_current_user)):
    """Get available voices for TTS"""
    try:
        if eleven_client:
            voices_response = eleven_client.voices.get_all()
            voices = []
            for voice in voices_response.voices:
                voices.append({
                    "voice_id": voice.voice_id,
                    "name": voice.name,
                    "category": voice.category or "premade",
                    "gender": voice.labels.get("gender", "unknown") if voice.labels else "unknown",
                    "language": voice.labels.get("language", "en") if voice.labels else "en",
                    "accent": voice.labels.get("accent", "unknown") if voice.labels else "unknown",
                    "preview_url": voice.preview_url
                })
            return {"voices": voices}
    except Exception as e:
        logging.error(f"Error fetching voices: {str(e)}")
    
    return {"voices": AVAILABLE_VOICES}

@api_router.post("/tts/generate")
async def generate_tts(request: TTSRequest, current_user: dict = Depends(get_current_user)):
    """Generate text-to-speech audio"""
    if not eleven_client:
        raise HTTPException(status_code=503, detail="TTS service not available")
    
    try:
        voice_settings = VoiceSettings(
            stability=request.stability,
            similarity_boost=request.similarity_boost
        )
        
        audio_generator = eleven_client.text_to_speech.convert(
            text=request.text,
            voice_id=request.voice_id,
            model_id="eleven_multilingual_v2",
            voice_settings=voice_settings
        )
        
        audio_data = b""
        for chunk in audio_generator:
            audio_data += chunk
        
        audio_b64 = base64.b64encode(audio_data).decode()
        audio_url = f"data:audio/mpeg;base64,{audio_b64}"
        
        await log_activity(
            current_user['user_id'], 
            "tts_generated", 
            "create", 
            f"Generated TTS: {request.text[:50]}...",
            {"voice_id": request.voice_id, "text_length": len(request.text)}
        )
        
        return {"audio_url": audio_url, "text": request.text, "voice_id": request.voice_id}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error generating TTS: {str(e)}")

# ============== IMAGE GENERATION & EDITING ==============

@api_router.post("/generate/image")
async def generate_image(prompt: str, current_user: dict = Depends(get_current_user)):
    user_doc = await db.users.find_one({"id": current_user['user_id']}, {"_id": 0})
    
    is_owner = user_doc.get('is_owner', False)
    has_subscription = await check_user_subscription(current_user['user_id'], "images")
    free_images = user_doc.get('free_images', 0)
    
    is_free_use = False
    
    if is_owner:
        pass
    elif has_subscription:
        pass
    elif free_images > 0:
        is_free_use = True
        await db.users.update_one(
            {"id": current_user['user_id']},
            {"$inc": {"free_images": -1}}
        )
    else:
        raise HTTPException(status_code=403, detail="لا يوجد لديك رصيد مجاني أو اشتراك")
    
    try:
        # Use OpenAI DALL-E for image generation
        if not openai_client:
            raise HTTPException(status_code=500, detail="OpenAI not configured")
        
        response = openai_client.images.generate(
            model="dall-e-3",
            prompt=prompt,
            size="1024x1024",
            quality="standard",
            n=1
        )
        image_data = response.data[0].url
        text = f"تم توليد الصورة: {prompt}"
        
        gen_record = ImageGeneration(
            user_id=current_user['user_id'],
            prompt=prompt,
            image_url=image_data,
            status="completed" if image_data else "failed",
            is_free=is_free_use
        )
        
        doc = gen_record.model_dump()
        doc['created_at'] = doc['created_at'].isoformat()
        await db.image_generations.insert_one(doc)
        
        await log_activity(
            current_user['user_id'],
            "image_generated",
            "create",
            f"Generated image: {prompt[:50]}...",
            {"is_free": is_free_use, "prompt": prompt}
        )
        
        updated_user = await db.users.find_one({"id": current_user['user_id']}, {"_id": 0, "password": 0})
        
        return {
            "id": gen_record.id, 
            "image_url": image_data, 
            "text": text,
            "free_images_remaining": updated_user.get('free_images', 0),
            "was_free": is_free_use
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"فشل توليد الصورة: {str(e)}")

@api_router.post("/images/edit")
async def edit_image(request: ImageEditRequest, current_user: dict = Depends(get_current_user)):
    """Add text to an image"""
    try:
        # Decode base64 image
        if request.image_base64.startswith('data:'):
            header, data = request.image_base64.split(',', 1)
        else:
            data = request.image_base64
        
        image_bytes = base64.b64decode(data)
        image = Image.open(io.BytesIO(image_bytes))
        
        if request.text:
            draw = ImageDraw.Draw(image)
            
            # Try to use a font, fallback to default
            try:
                font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", request.font_size)
            except:
                font = ImageFont.load_default()
            
            # Calculate text position
            text_bbox = draw.textbbox((0, 0), request.text, font=font)
            text_width = text_bbox[2] - text_bbox[0]
            text_height = text_bbox[3] - text_bbox[1]
            
            img_width, img_height = image.size
            x = (img_width - text_width) // 2
            
            if request.text_position == "top":
                y = 20
            elif request.text_position == "center":
                y = (img_height - text_height) // 2
            else:  # bottom
                y = img_height - text_height - 20
            
            # Add text shadow for better visibility
            shadow_color = "#000000"
            draw.text((x+2, y+2), request.text, font=font, fill=shadow_color)
            draw.text((x, y), request.text, font=font, fill=request.text_color)
        
        # Convert back to base64
        buffer = io.BytesIO()
        image.save(buffer, format="PNG")
        edited_b64 = base64.b64encode(buffer.getvalue()).decode()
        edited_url = f"data:image/png;base64,{edited_b64}"
        
        # Save to database
        edit_record = ImageGeneration(
            user_id=current_user['user_id'],
            prompt=f"Edited image with text: {request.text}",
            image_url=request.image_base64,
            edited_image_url=edited_url,
            status="completed",
            is_edit=True
        )
        
        doc = edit_record.model_dump()
        doc['created_at'] = doc['created_at'].isoformat()
        await db.image_generations.insert_one(doc)
        
        await log_activity(
            current_user['user_id'],
            "image_edited",
            "edit",
            f"Added text to image: {request.text[:30]}...",
            {"text": request.text, "position": request.text_position}
        )
        
        return {"id": edit_record.id, "edited_image_url": edited_url}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error editing image: {str(e)}")

@api_router.post("/images/upload-edit")
async def upload_and_edit_image(
    file: UploadFile = File(...),
    text: str = Form(None),
    text_position: str = Form("bottom"),
    text_color: str = Form("#FFFFFF"),
    font_size: int = Form(40),
    current_user: dict = Depends(get_current_user)
):
    """Upload an image and optionally add text"""
    try:
        contents = await file.read()
        image_b64 = base64.b64encode(contents).decode()
        image_url = f"data:{file.content_type};base64,{image_b64}"
        
        if text:
            request = ImageEditRequest(
                image_base64=image_url,
                text=text,
                text_position=text_position,
                text_color=text_color,
                font_size=font_size
            )
            return await edit_image(request, current_user)
        
        await log_activity(
            current_user['user_id'],
            "image_uploaded",
            "create",
            f"Uploaded image: {file.filename}"
        )
        
        return {"image_url": image_url, "filename": file.filename}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error uploading image: {str(e)}")

@api_router.get("/generate/images/history")
async def get_image_history(current_user: dict = Depends(get_current_user)):
    images = await db.image_generations.find(
        {"user_id": current_user['user_id']},
        {"_id": 0}
    ).sort("created_at", -1).to_list(100)
    return images

@api_router.post("/download/log")
async def log_download(item_type: str, item_id: str, current_user: dict = Depends(get_current_user)):
    """Log when user downloads an image or video"""
    await log_activity(
        current_user['user_id'],
        f"{item_type}_downloaded",
        "download",
        f"Downloaded {item_type}: {item_id}",
        {"item_type": item_type, "item_id": item_id}
    )
    return {"message": "Download logged"}

# ============== VIDEO GENERATION ==============

@api_router.post("/generate/video")
async def generate_video(
    prompt: str, 
    voice_id: Optional[str] = None,
    voice_text: Optional[str] = None,
    current_user: dict = Depends(get_current_user)
):
    user_doc = await db.users.find_one({"id": current_user['user_id']}, {"_id": 0})
    
    is_owner = user_doc.get('is_owner', False)
    has_subscription = await check_user_subscription(current_user['user_id'], "videos")
    free_videos = user_doc.get('free_videos', 0)
    
    is_free_use = False
    
    if is_owner:
        pass
    elif has_subscription:
        pass
    elif free_videos > 0:
        is_free_use = True
        await db.users.update_one(
            {"id": current_user['user_id']},
            {"$inc": {"free_videos": -1}}
        )
    else:
        raise HTTPException(status_code=403, detail="لا يوجد لديك رصيد مجاني أو اشتراك")
    
    audio_url = None
    if voice_id and voice_text and eleven_client:
        try:
            voice_settings = VoiceSettings(stability=0.5, similarity_boost=0.75)
            audio_generator = eleven_client.text_to_speech.convert(
                text=voice_text,
                voice_id=voice_id,
                model_id="eleven_multilingual_v2",
                voice_settings=voice_settings
            )
            
            audio_data = b""
            for chunk in audio_generator:
                audio_data += chunk
            
            audio_b64 = base64.b64encode(audio_data).decode()
            audio_url = f"data:audio/mpeg;base64,{audio_b64}"
        except Exception as e:
            logging.error(f"Error generating audio for video: {str(e)}")
    
    gen_record = VideoGeneration(
        user_id=current_user['user_id'],
        prompt=prompt,
        audio_url=audio_url,
        voice_id=voice_id,
        status="processing",
        is_free=is_free_use
    )
    
    doc = gen_record.model_dump()
    doc['created_at'] = doc['created_at'].isoformat()
    await db.video_generations.insert_one(doc)
    
    await log_activity(
        current_user['user_id'],
        "video_generated",
        "create",
        f"Generated video: {prompt[:50]}...",
        {"is_free": is_free_use, "has_voice": bool(voice_id), "prompt": prompt}
    )
    
    updated_user = await db.users.find_one({"id": current_user['user_id']}, {"_id": 0, "password": 0})
    
    return {
        "id": gen_record.id, 
        "status": "processing", 
        "message": "جاري توليد الفيديو",
        "audio_url": audio_url,
        "free_videos_remaining": updated_user.get('free_videos', 0),
        "was_free": is_free_use
    }

@api_router.post("/videos/upload")
async def upload_video(
    file: UploadFile = File(...),
    current_user: dict = Depends(get_current_user)
):
    """Upload a video for editing"""
    try:
        contents = await file.read()
        video_b64 = base64.b64encode(contents).decode()
        video_url = f"data:{file.content_type};base64,{video_b64}"
        
        await log_activity(
            current_user['user_id'],
            "video_uploaded",
            "create",
            f"Uploaded video: {file.filename}"
        )
        
        return {"video_url": video_url, "filename": file.filename}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error uploading video: {str(e)}")

@api_router.get("/generate/videos/history")
async def get_video_history(current_user: dict = Depends(get_current_user)):
    videos = await db.video_generations.find(
        {"user_id": current_user['user_id']},
        {"_id": 0}
    ).sort("created_at", -1).to_list(100)
    return videos

# ============== WEBSITE REQUESTS ==============

@api_router.post("/requests/create", response_model=WebsiteRequest)
async def create_request(request_data: WebsiteRequestCreate, current_user: dict = Depends(get_current_user)):
    user_doc = await db.users.find_one({"id": current_user['user_id']}, {"_id": 0})
    is_owner = user_doc.get('is_owner', False)
    credits = user_doc.get('credits', 0)
    has_free_trial = user_doc.get('free_website_trial', False)
    
    is_trial = request_data.is_trial
    required_credits = 50
    
    if is_trial:
        if not has_free_trial and not is_owner:
            raise HTTPException(status_code=403, detail="لقد استخدمت تجربتك المجانية")
        
        if not is_owner:
            await db.users.update_one(
                {"id": current_user['user_id']},
                {"$set": {"free_website_trial": False}}
            )
    else:
        if not is_owner and credits < required_credits:
            raise HTTPException(status_code=403, detail=f"رصيدك غير كافٍ. تحتاج {required_credits} نقطة")
        
        if not is_owner:
            await db.users.update_one(
                {"id": current_user['user_id']},
                {"$inc": {"credits": -required_credits}}
            )
    
    request_obj = WebsiteRequest(
        user_id=current_user['user_id'],
        credits_used=0 if (is_owner or is_trial) else required_credits,
        is_trial=is_trial,
        **{k: v for k, v in request_data.model_dump().items() if k != 'is_trial'}
    )
    
    doc = request_obj.model_dump()
    doc['created_at'] = doc['created_at'].isoformat()
    await db.website_requests.insert_one(doc)
    
    await log_activity(
        current_user['user_id'],
        "website_requested",
        "create",
        f"Website request: {request_data.title}",
        {"is_trial": is_trial, "credits_used": request_obj.credits_used}
    )
    
    return request_obj

@api_router.post("/requests/{request_id}/generate-suggestions")
async def generate_suggestions(request_id: str, current_user: dict = Depends(get_current_user)):
    request_doc = await db.website_requests.find_one({"id": request_id}, {"_id": 0})
    if not request_doc:
        raise HTTPException(status_code=404, detail="Request not found")
    
    if request_doc['user_id'] != current_user['user_id'] and current_user['role'] not in ['admin', 'super_admin', 'owner']:
        raise HTTPException(status_code=403, detail="Access denied")
    
    is_trial = request_doc.get('is_trial', False)
    
    try:
        system_msg = "أنت مصمم مواقع محترف. قم بتقديم اقتراحات تفصيلية لتصميم الموقع بناءً على متطلبات العميل. أجب بالعربية."
        
        if is_trial:
            system_msg += " هذه تجربة مجانية، قدم ملخصاً موجزاً فقط."
        
        # Use OpenAI GPT for website suggestions
        if not openai_client:
            raise HTTPException(status_code=500, detail="OpenAI not configured")
        
        prompt = f"""العميل يريد موقع بالمواصفات التالية:
العنوان: {request_doc['title']}
الوصف: {request_doc['description']}
المتطلبات: {request_doc['requirements']}
نوع العمل: {request_doc.get('business_type', 'غير محدد')}
الجمهور المستهدف: {request_doc.get('target_audience', 'غير محدد')}
الألوان المفضلة: {request_doc.get('preferred_colors', 'غير محدد')}

{"تجربة مجانية - ملخص موجز فقط." if is_trial else "قدم اقتراحات احترافية كاملة."}"""
        
        chat_response = openai_client.chat.completions.create(
            model="gpt-4o",
            messages=[
                {"role": "system", "content": system_msg},
                {"role": "user", "content": prompt}
            ],
            max_tokens=2000
        )
        response = chat_response.choices[0].message.content
        
        if is_trial:
            response += "\n\n---\n🔒 **معاينة محدودة**\nللحصول على التصميم الكامل، يرجى شراء نقاط."
        
        await db.website_requests.update_one(
            {"id": request_id},
            {"$set": {"ai_suggestions": response}}
        )
        
        return {"suggestions": response, "is_trial": is_trial}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"AI generation failed: {str(e)}")

@api_router.get("/requests")
async def get_requests(current_user: dict = Depends(get_current_user)):
    if current_user['role'] in ['admin', 'super_admin', 'owner']:
        requests = await db.website_requests.find({}, {"_id": 0}).sort("created_at", -1).to_list(1000)
    else:
        requests = await db.website_requests.find({"user_id": current_user['user_id']}, {"_id": 0}).sort("created_at", -1).to_list(1000)
    return requests

@api_router.get("/requests/{request_id}")
async def get_request(request_id: str, current_user: dict = Depends(get_current_user)):
    request_doc = await db.website_requests.find_one({"id": request_id}, {"_id": 0})
    if not request_doc:
        raise HTTPException(status_code=404, detail="Request not found")
    
    if request_doc['user_id'] != current_user['user_id'] and current_user['role'] not in ['admin', 'super_admin', 'owner']:
        raise HTTPException(status_code=403, detail="Access denied")
    
    return request_doc

@api_router.put("/requests/{request_id}/status")
async def update_request_status(request_id: str, status: str, admin: dict = Depends(require_admin)):
    result = await db.website_requests.update_one(
        {"id": request_id},
        {"$set": {"status": status}}
    )
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Request not found")
    return {"message": "Status updated"}

# ============== PAYMENTS ==============

@api_router.post("/payments/create")
async def create_payment(payment_data: PaymentCreate, current_user: dict = Depends(get_current_user)):
    user_doc = await db.users.find_one({"id": current_user['user_id']}, {"_id": 0})
    currency = "SAR" if user_doc.get('country') == 'SA' else "USD"
    
    payment = Payment(
        user_id=current_user['user_id'],
        user_name=user_doc.get('name', 'Unknown'),
        user_email=user_doc.get('email', ''),
        payment_type=payment_data.payment_type,
        amount=payment_data.amount,
        currency=currency,
        proof_image_url=payment_data.proof_base64
    )
    
    doc = payment.model_dump()
    doc['created_at'] = doc['created_at'].isoformat()
    await db.payments.insert_one(doc)
    
    await log_activity(
        current_user['user_id'],
        "payment_created",
        "create",
        f"Payment: {payment_data.payment_type} - {payment_data.amount} {currency}",
        {"payment_type": payment_data.payment_type, "amount": payment_data.amount}
    )
    
    payment_type_ar = {
        "credits": "شراء نقاط",
        "subscription_images": "اشتراك صور",
        "subscription_videos": "اشتراك فيديو",
        "images_monthly": "اشتراك صور شهري",
        "videos_monthly": "اشتراك فيديو شهري"
    }.get(payment_data.payment_type, payment_data.payment_type)
    
    message = f"""💰 دفعة جديدة في Zitex!

👤 العميل: {user_doc.get('name', 'Unknown')}
📧 البريد: {user_doc.get('email', '')}
💳 النوع: {payment_type_ar}
💵 المبلغ: {payment_data.amount} {currency}

🔗 راجع من لوحة التحكم للموافقة"""
    
    await send_whatsapp_notification(message)
    
    return payment

@api_router.get("/payments")
async def get_payments(current_user: dict = Depends(get_current_user)):
    if current_user['role'] in ['admin', 'super_admin', 'owner']:
        payments = await db.payments.find({}, {"_id": 0}).sort("created_at", -1).to_list(1000)
    else:
        payments = await db.payments.find({"user_id": current_user['user_id']}, {"_id": 0}).sort("created_at", -1).to_list(1000)
    return payments

CREDITS_PACKAGES = [
    {"id": "starter", "name": "باقة المبتدئ", "credits": 100, "price_sar": 50, "price_usd": 13},
    {"id": "pro", "name": "باقة المحترف", "credits": 500, "price_sar": 200, "price_usd": 53},
    {"id": "enterprise", "name": "باقة الأعمال", "credits": 2000, "price_sar": 700, "price_usd": 187},
]

@api_router.put("/payments/{payment_id}/approve")
async def approve_payment(payment_id: str, admin_notes: Optional[str] = None, admin: dict = Depends(require_admin)):
    payment_doc = await db.payments.find_one({"id": payment_id}, {"_id": 0})
    if not payment_doc:
        raise HTTPException(status_code=404, detail="Payment not found")
    
    await db.payments.update_one(
        {"id": payment_id},
        {"$set": {"status": "approved", "admin_notes": admin_notes}}
    )
    
    payment_type = payment_doc['payment_type']
    user_id = payment_doc['user_id']
    
    if payment_type == "credits":
        for pkg in CREDITS_PACKAGES:
            if payment_doc['amount'] == (pkg['price_sar'] if payment_doc['currency'] == 'SAR' else pkg['price_usd']):
                await db.users.update_one(
                    {"id": user_id},
                    {"$inc": {"credits": pkg['credits']}}
                )
                break
    elif payment_type in ["subscription_images", "images_monthly"]:
        expires = (datetime.now(timezone.utc) + timedelta(days=30)).isoformat()
        await db.users.update_one(
            {"id": user_id},
            {"$set": {"subscription_type": "images", "subscription_expires": expires}}
        )
    elif payment_type in ["subscription_videos", "videos_monthly"]:
        expires = (datetime.now(timezone.utc) + timedelta(days=30)).isoformat()
        await db.users.update_one(
            {"id": user_id},
            {"$set": {"subscription_type": "videos", "subscription_expires": expires}}
        )
    
    await log_activity(
        admin['id'] if isinstance(admin, dict) and 'id' in admin else 'admin',
        "payment_approved",
        "edit",
        f"Approved payment {payment_id}",
        {"payment_id": payment_id, "user_id": user_id}
    )
    
    return {"message": "Payment approved"}

@api_router.put("/payments/{payment_id}/reject")
async def reject_payment(payment_id: str, admin_notes: Optional[str] = None, admin: dict = Depends(require_admin)):
    result = await db.payments.update_one(
        {"id": payment_id},
        {"$set": {"status": "rejected", "admin_notes": admin_notes}}
    )
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Payment not found")
    return {"message": "Payment rejected"}

# ============== WEBSITES ==============

@api_router.post("/websites/create")
async def create_website(request_id: str, url: str, preview_image: Optional[str] = None, admin: dict = Depends(require_admin)):
    request_doc = await db.website_requests.find_one({"id": request_id}, {"_id": 0})
    if not request_doc:
        raise HTTPException(status_code=404, detail="Request not found")
    
    website = Website(
        request_id=request_id,
        user_id=request_doc['user_id'],
        url=url,
        preview_image=preview_image
    )
    
    doc = website.model_dump()
    doc['created_at'] = doc['created_at'].isoformat()
    await db.websites.insert_one(doc)
    
    return website

@api_router.get("/websites")
async def get_websites(current_user: dict = Depends(get_current_user)):
    if current_user['role'] in ['admin', 'super_admin', 'owner']:
        websites = await db.websites.find({}, {"_id": 0}).sort("created_at", -1).to_list(1000)
    else:
        websites = await db.websites.find({"user_id": current_user['user_id']}, {"_id": 0}).sort("created_at", -1).to_list(1000)
    return websites

@api_router.put("/websites/{website_id}/status")
async def update_website_status(website_id: str, status: str, admin: dict = Depends(require_admin)):
    result = await db.websites.update_one(
        {"id": website_id},
        {"$set": {"status": status}}
    )
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Website not found")
    return {"message": "Status updated"}

# ============== PRICING ==============

@api_router.get("/pricing")
async def get_pricing():
    return {
        "credits_packages": CREDITS_PACKAGES,
        "subscriptions": {
            "images_monthly": {"price_sar": 100, "price_usd": 27},
            "images_single": {"price_sar": 10, "price_usd": 3},
            "videos_monthly": {"price_sar": 150, "price_usd": 40},
            "videos_single": {"price_sar": 20, "price_usd": 5},
        },
        "website_credits": {"simple": 50, "advanced": 150, "ecommerce": 300},
        "free_trial": {"images": 3, "videos": 3, "website_preview": True}
    }

@api_router.get("/settings/payment")
async def get_payment_settings():
    settings = await db.settings.find_one({"type": "payment"}, {"_id": 0})
    if not settings:
        return {"bank_name": "", "bank_iban": "", "bank_account_name": "", "paypal_email": "", "owner_whatsapp": OWNER_WHATSAPP}
    return settings

# ============== ADMIN ==============

@api_router.get("/admin/stats")
async def get_admin_stats(admin: dict = Depends(require_admin)):
    return AdminStats(
        total_users=await db.users.count_documents({}),
        total_requests=await db.website_requests.count_documents({}),
        pending_requests=await db.website_requests.count_documents({"status": "pending"}),
        completed_requests=await db.website_requests.count_documents({"status": "completed"}),
        pending_payments=await db.payments.count_documents({"status": "pending"}),
        approved_payments=await db.payments.count_documents({"status": "approved"}),
        total_websites=await db.websites.count_documents({}),
        total_images_generated=await db.image_generations.count_documents({}),
        total_videos_generated=await db.video_generations.count_documents({}),
        total_activities=await db.activity_logs.count_documents({})
    )

@api_router.get("/admin/users")
async def get_all_users(admin: dict = Depends(require_admin)):
    users = await db.users.find({}, {"_id": 0, "password": 0}).sort("created_at", -1).to_list(1000)
    return users

@api_router.get("/admin/users/{user_id}/activity")
async def get_user_activity(user_id: str, admin: dict = Depends(require_admin)):
    """Get activity log for a specific user"""
    activities = await db.activity_logs.find(
        {"user_id": user_id},
        {"_id": 0}
    ).sort("created_at", -1).to_list(500)
    return activities

@api_router.get("/admin/activity")
async def get_all_activity(limit: int = 100, admin: dict = Depends(require_admin)):
    """Get all activity logs"""
    activities = await db.activity_logs.find(
        {},
        {"_id": 0}
    ).sort("created_at", -1).to_list(limit)
    return activities

@api_router.put("/admin/settings/payment")
async def update_payment_settings(settings: SiteSettings, admin: dict = Depends(require_admin)):
    await db.settings.update_one(
        {"type": "payment"},
        {"$set": {**settings.model_dump(), "type": "payment"}},
        upsert=True
    )
    return {"message": "Settings updated"}

@api_router.put("/admin/users/{user_id}/role")
async def update_user_role(user_id: str, role: str, current_user: dict = Depends(get_current_user)):
    """Update user role - only owner can promote to super_admin"""
    user_doc = await db.users.find_one({"id": current_user['user_id']}, {"_id": 0})
    current_role = user_doc.get('role', 'client')
    current_level = ROLE_LEVELS.get(current_role, 0)
    
    target_level = ROLE_LEVELS.get(role, 0)
    
    # Can only assign roles lower than your own
    if target_level >= current_level:
        raise HTTPException(status_code=403, detail="Cannot assign role equal or higher than your own")
    
    # Only owner can create super_admin
    if role == "super_admin" and current_role != "owner":
        raise HTTPException(status_code=403, detail="Only owner can create super admins")
    
    result = await db.users.update_one(
        {"id": user_id},
        {"$set": {"role": role}}
    )
    
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="User not found")
    
    await log_activity(
        current_user['user_id'],
        "role_updated",
        "edit",
        f"Updated user {user_id} role to {role}"
    )
    
    return {"message": f"User role updated to {role}"}

@api_router.put("/admin/users/{user_id}/deactivate")
async def deactivate_user(user_id: str, admin: dict = Depends(require_admin)):
    """Deactivate a user account"""
    target_user = await db.users.find_one({"id": user_id}, {"_id": 0})
    if not target_user:
        raise HTTPException(status_code=404, detail="User not found")
    
    # Cannot deactivate owner
    if target_user.get('is_owner'):
        raise HTTPException(status_code=403, detail="Cannot deactivate owner account")
    
    # Check role hierarchy
    admin_level = ROLE_LEVELS.get(admin.get('role', 'admin'), 50)
    target_level = ROLE_LEVELS.get(target_user.get('role', 'client'), 10)
    
    if target_level >= admin_level:
        raise HTTPException(status_code=403, detail="Cannot deactivate user with equal or higher role")
    
    await db.users.update_one(
        {"id": user_id},
        {"$set": {"is_active": False}}
    )
    
    await log_activity(
        admin.get('id', 'admin'),
        "user_deactivated",
        "edit",
        f"Deactivated user {user_id}"
    )
    
    return {"message": "User deactivated"}

@api_router.put("/admin/users/{user_id}/activate")
async def activate_user(user_id: str, admin: dict = Depends(require_admin)):
    """Activate a user account"""
    result = await db.users.update_one(
        {"id": user_id},
        {"$set": {"is_active": True}}
    )
    
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="User not found")
    
    return {"message": "User activated"}

@api_router.put("/admin/users/{user_id}/make-owner")
async def make_user_owner(user_id: str, current_user: dict = Depends(get_current_user)):
    """Make user an owner - only existing owner can do this"""
    requester = await db.users.find_one({"id": current_user['user_id']}, {"_id": 0})
    if not requester.get('is_owner'):
        raise HTTPException(status_code=403, detail="Only owner can transfer ownership")
    
    result = await db.users.update_one(
        {"id": user_id},
        {"$set": {"is_owner": True, "role": "owner"}}
    )
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="User not found")
    
    return {"message": "User is now owner"}

@api_router.put("/admin/users/{user_id}/add-credits")
async def add_user_credits(user_id: str, credits: int, admin: dict = Depends(require_admin)):
    result = await db.users.update_one(
        {"id": user_id},
        {"$inc": {"credits": credits}}
    )
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="User not found")
    
    await log_activity(
        admin.get('id', 'admin'),
        "credits_added",
        "edit",
        f"Added {credits} credits to user {user_id}"
    )
    
    return {"message": f"Added {credits} credits"}

@api_router.put("/admin/users/{user_id}/add-free-trials")
async def add_free_trials(user_id: str, images: int = 0, videos: int = 0, admin: dict = Depends(require_admin)):
    update = {}
    if images > 0:
        update["free_images"] = images
    if videos > 0:
        update["free_videos"] = videos
    
    if update:
        result = await db.users.update_one(
            {"id": user_id},
            {"$inc": update}
        )
        if result.matched_count == 0:
            raise HTTPException(status_code=404, detail="User not found")
    
    return {"message": f"Added {images} free images, {videos} free videos"}

# ============== APP SETUP ==============

# Import and setup chat router
from routers import chat_router, set_ai_assistant, deployment_router, set_deployment_service
from services.ai_chat_service import AIAssistant
from services.deployment_service import DeploymentService

# Initialize AI Assistant (Independent - uses OpenAI and Gemini directly)
ai_assistant = AIAssistant(
    db=db,
    openai_key=OPENAI_API_KEY,
    gemini_key=GEMINI_API_KEY,
    elevenlabs_key=ELEVENLABS_API_KEY
)
set_ai_assistant(ai_assistant)

# Initialize Deployment Service
deployment_service = DeploymentService(db=db)
set_deployment_service(deployment_service)

# Include routers
app.include_router(api_router)
app.include_router(chat_router, prefix="/api")
app.include_router(deployment_router, prefix="/api")

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get('CORS_ORIGINS', '*').split(','),
    allow_methods=["*"],
    allow_headers=["*"],
)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()
