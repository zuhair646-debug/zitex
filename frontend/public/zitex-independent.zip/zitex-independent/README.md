# Zitex - منصة الإبداع بالذكاء الاصطناعي
# 🚀 نسخة مستقلة 100%

## ✅ هذه النسخة مستقلة تماماً ولا تحتاج Emergent

---

## 📦 المتطلبات

### برامج يجب تثبيتها:
1. **Node.js** (v18+) - https://nodejs.org
2. **Python** (v3.10+) - https://python.org
3. **MongoDB** - https://mongodb.com/try/download/community

### مفاتيح API مطلوبة:
1. **OpenAI API Key** (مطلوب) - https://platform.openai.com/api-keys
   - للمحادثة (GPT-4o)
   - للصور (DALL-E 3)
   - للفيديو (Sora) - إذا متاح
   
2. **Google Gemini** (اختياري) - https://makersuite.google.com/app/apikey
   - للصور البديلة
   
3. **ElevenLabs** (اختياري) - https://elevenlabs.io
   - لتحويل النص إلى صوت

---

## 🔧 خطوات التثبيت

### 1️⃣ قاعدة البيانات
```bash
# شغّل MongoDB
mongod --dbpath /path/to/data
```

### 2️⃣ Backend (الخادم)
```bash
cd backend

# أنشئ virtual environment
python -m venv venv
source venv/bin/activate  # Linux/Mac
# أو
venv\Scripts\activate  # Windows

# ثبّت المكتبات
pip install -r requirements.txt

# انسخ ملف الإعدادات
cp .env.example .env

# عدّل .env وأضف مفاتيحك
```

### 3️⃣ إعداد .env
افتح `backend/.env` وأضف:
```env
MONGO_URL=mongodb://localhost:27017
DB_NAME=zitex
OPENAI_API_KEY=sk-xxxxxxxx  # ← مفتاحك من OpenAI
GEMINI_API_KEY=             # ← اختياري
JWT_SECRET=نص_عشوائي_طويل
ELEVENLABS_API_KEY=         # ← اختياري
```

### 4️⃣ Frontend (الواجهة)
```bash
cd frontend

# ثبّت المكتبات
npm install

# عدّل .env
echo "REACT_APP_BACKEND_URL=http://localhost:8001" > .env
```

---

## ▶️ التشغيل

### Terminal 1 - Backend:
```bash
cd backend
source venv/bin/activate
uvicorn server:app --host 0.0.0.0 --port 8001 --reload
```

### Terminal 2 - Frontend:
```bash
cd frontend
npm start
```

### افتح المتصفح:
```
http://localhost:3000
```

---

## 💰 تكلفة التشغيل الشهرية

| الخدمة | التكلفة |
|--------|---------|
| OpenAI (حسب الاستخدام) | $20-100 |
| استضافة (اختياري) | $5-25 |
| ElevenLabs (اختياري) | $5-22 |
| **المجموع** | **$25-147** |

---

## 📁 هيكل المشروع

```
zitex/
├── backend/
│   ├── .env              # ← أضف مفاتيحك هنا
│   ├── server.py         # الخادم الرئيسي
│   ├── requirements.txt
│   ├── services/
│   │   └── ai_chat_service.py  # خدمة الذكاء الاصطناعي
│   └── routers/
│       └── chat_router.py
├── frontend/
│   ├── .env
│   ├── package.json
│   └── src/
│       └── pages/
│           └── AIChat.js  # صفحة الشات
└── README.md
```

---

## 🔐 ملاحظات أمنية

1. **لا تشارك** ملف `.env` أبداً
2. **أضف** `.env` إلى `.gitignore`
3. **غيّر** `JWT_SECRET` لقيمة عشوائية طويلة
4. **لا ترفع** المفاتيح على GitHub

---

## ❓ المشاكل الشائعة

### "OPENAI_API_KEY not found"
- تأكد من إضافة المفتاح في `backend/.env`

### "MongoDB connection failed"
- تأكد أن MongoDB شغّال
- تحقق من `MONGO_URL` في `.env`

### "Module not found"
```bash
pip install -r requirements.txt
```

---

## 🎬 الميزات

- ✅ محادثة ذكية (GPT-4o)
- ✅ توليد صور (DALL-E 3)
- ✅ توليد فيديو (Sora - إذا متاح)
- ✅ تحويل نص لصوت (ElevenLabs)
- ✅ إنشاء مواقع
- ✅ إدارة المشاريع

---

## 📞 الدعم

هذه نسخة مستقلة. للدعم:
- OpenAI: https://help.openai.com
- Google AI: https://ai.google.dev

---

**تم إنشاؤها بواسطة Zitex - نسخة مستقلة**
