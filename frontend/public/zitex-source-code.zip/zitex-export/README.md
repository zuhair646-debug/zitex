# Zitex - منصة الإبداع بالذكاء الاصطناعي

## المتطلبات
- Node.js 18+
- Python 3.10+
- MongoDB

## التثبيت

### Backend
```bash
cd backend
pip install -r requirements.txt
# أضف المفاتيح في .env
python server.py
```

### Frontend
```bash
cd frontend
npm install
# أضف الرابط في .env
npm start
```

## ملفات .env المطلوبة

### backend/.env
```
MONGO_URL=mongodb://localhost:27017
DB_NAME=zitex
JWT_SECRET=your-secret-key
EMERGENT_API_KEY=your-openai-key
ELEVENLABS_API_KEY=your-elevenlabs-key
```

### frontend/.env
```
REACT_APP_BACKEND_URL=http://localhost:8001
```
